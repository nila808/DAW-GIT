import pytest
from PyQt6.QtWidgets import QMessageBox

@pytest.fixture(autouse=True)
def auto_accept_messageboxes(monkeypatch):
    """
    Automatically clicks 'OK' on any QMessageBox that appears.
    Applies to all tests via autouse=True.
    """
    def auto_exec(self):
        return QMessageBox.StandardButton.Ok  # Simulate OK button

    monkeypatch.setattr(QMessageBox, "exec", auto_exec)