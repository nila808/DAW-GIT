from rich import print

def test_colored_output():
    print("[bold red]🔥 This is red[/bold red]")
    print("[bold green]✅ This is green[/bold green]")
    print("[bold yellow]⚠️ This is yellow[/bold yellow]")
